#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QThread>
#include "Work.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

signals:
    void doWorkA();
    void doWorkB();

private:
    Ui::MainWindow *ui;
    QThread *m_thread;
    Work m_work;
};

#endif // MAINWINDOW_H
