#ifndef WORKTHREAD_H
#define WORKTHREAD_H

#include <QObject>
#include <QThread>

class Work : public QObject
{
    Q_OBJECT
public:
    explicit Work(QObject *parent = nullptr);

signals:

public slots:
    void doWorkA();
    void doWorkB();
};

#endif // WORKTHREAD_H
