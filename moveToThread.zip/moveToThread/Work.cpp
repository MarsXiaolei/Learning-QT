#include "Work.h"
#include <QDebug>

Work::Work(QObject *parent) : QObject(parent)
{
    qDebug()<<"Work::Work === "<<QThread::currentThreadId();
}

void Work::doWorkA()
{
    qDebug()<<"Work::doWorkA() === "<<QThread::currentThreadId();
}

void Work::doWorkB()
{
    qDebug()<<"Work::doWorkB() === "<<QThread::currentThreadId();
}
