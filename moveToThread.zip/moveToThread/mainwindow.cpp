#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    m_thread = new QThread(this);
    qDebug()<<"MainWindow::MainWindow === "<<QThread::currentThreadId();
    connect(this,&MainWindow::doWorkA,&m_work,&Work::doWorkA);
    connect(this,&MainWindow::doWorkB,&m_work,&Work::doWorkB);
    /// 将Work对象移入子线程中
    m_work.moveToThread(m_thread);
    m_thread->start();
    /// 发送信号去执行槽函数（相当于run）
    emit doWorkA();
    emit doWorkB();
}

MainWindow::~MainWindow()
{
    m_thread->quit();
    m_thread->wait();
    //delete m_thread;
    delete ui;
}
